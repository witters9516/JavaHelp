/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria_shawnwitter;

import java.sql.*;

public class PizzaToppingsTable 
{
    final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDb";

    public PizzaToppingsTable()
    {
       try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           
           String sqlDrop1 = "DROP TABLE PizzaToppings";
           stmt.execute(sqlDrop1);
            
            
           String sqlStmt1 = "CREATE TABLE PizzaToppings(ToppingName CHAR(40), Price DOUBLE)";
           stmt.execute(sqlStmt1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        } 
    }
    
    public void insertRow(String toppingName, double price)
    {
        try
        {
            Connection con = DriverManager.getConnection(DB_URL);
            Statement stmt = con.createStatement();

            //Create add statements to insert data.
            String sqlAdd = "INSERT INTO PizzaToppings(ToppingName, Price) VALUES(" + toppingName + ", " + price + ")";
            stmt.executeUpdate(sqlAdd);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        } 
    }
    
    public void displayResultSet()
    {
       //ResultSet result1 = new ResultSet();
       try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "SELECT * FROM PizzaToppings";
            ResultSet result1 = stmt.executeQuery(sqlDisplay1);
            
            //Display Database
            System.out.println("PizzaToppings Table:");
            System.out.println("Topping Name:\t Price");
            
            while (result1.next())
                System.out.println(result1.getString(1));
            
            //return result1;

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void updateRow(String new_ToppingName, double price, String original_ToppingName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "UPDATE PizzaToppings SET ToppingName=" + new_ToppingName + ", Price=" + price +
                    "WHERE ToppingName=" + original_ToppingName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void deleteRow(String original_ToppingName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "DELETE FROM PizzaToppings WHERE ToppingName=" + original_ToppingName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}
