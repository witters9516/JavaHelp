/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria;

/**
 *
 * @author MCook
 */

import javax.swing.JFrame;

public class Pizzeria 
{
    public static void main(String[] args) 
    {
        JFrame frame = new PizzeriaFrame();
	//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setTitle("Pizza Price");
	//frame.setVisible(true);
    }
    
}
