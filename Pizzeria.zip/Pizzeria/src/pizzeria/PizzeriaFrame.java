/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria;

/**
 *
 * @author MCook
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

public class PizzeriaFrame extends JFrame
{
     private JFrame frame;
     private JPanel pizzaPanel, centerPanel, pricePanel, toppingCheckBoxPanel, sizeRadioButtonPanel, crustRadioButtonPanel;
     private final int FRAME_WIDTH = 300;
     private final int FRAME_HEIGHT = 500;
     private ButtonGroup crustGroup, sizeGroup;
     private JRadioButton smallButton, mediumButton, largeButton, extraLargeButton, 
                        thinButton, handTossedButton, deepDishButton, stuffCrustButton, gutBusterButton;
     private JCheckBox pepperoniCheckBox, mushroomsCheckBox, sausageCheckBox, baconCheckBox, hamCheckBox, chickenCheckBox;
     private JTextField priceTextField;
     private double price = 0.0;
     private double topPrice = 0.0;
     private double showPrice = 0.0;
     
     private JButton calcPriceButton;
     private JLabel label;
     private JPanel resultsPanel;

       private ActionListener listener = new PriceListener();
       private ActionListener listener2 = new DisplayPriceListener();
       

       public PizzeriaFrame() 
       {
          pizzaPanel = new JPanel();
          pizzaPanel.setLayout(new BorderLayout(10, 10));
          createSizeRadioButtonPanel();
          createCrustRadioButtonPanel();
          createToppngCheckBoxPanel();
          //createPricePanel();
          createCenterPanel();
          createButtonAndLabel();
           pizzaPanel.add(centerPanel, BorderLayout.CENTER);
           pizzaPanel.add(resultsPanel, BorderLayout.PAGE_END);
           ///pizzaPanel.add(calcPriceButton);
           //pizzaPanel.add(label, BorderLayout.CENTER);
           frame = new JFrame("Pizza Price");
           
           frame.add(pizzaPanel, BorderLayout.CENTER);
           
           frame.setPreferredSize(new Dimension(FRAME_WIDTH, FRAME_HEIGHT));
           frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           frame.pack();
           frame.setLocation(100, 100);
           frame.setVisible(true);
    }

    private void createSizeRadioButtonPanel() 
    {
        sizeRadioButtonPanel = new JPanel();
        sizeRadioButtonPanel.setLayout(new GridLayout(2, 2));
        sizeRadioButtonPanel.setBorder(new TitledBorder(new EtchedBorder(), "Size"));
        sizeGroup = new ButtonGroup();
        
        smallButton = new JRadioButton("Small");
        sizeGroup.add(smallButton);
        smallButton.addActionListener(listener);
        sizeRadioButtonPanel.add(smallButton);
        
        mediumButton = new JRadioButton("Medium");
        sizeGroup.add(mediumButton);
        mediumButton.addActionListener(listener);
        sizeRadioButtonPanel.add(mediumButton);
        
        largeButton = new JRadioButton("Large");
        sizeGroup.add(largeButton);
        largeButton.addActionListener(listener);
        sizeRadioButtonPanel.add(largeButton);
        
        extraLargeButton = new JRadioButton("Extra Large");
        sizeGroup.add(extraLargeButton);
        extraLargeButton.addActionListener(listener);
        sizeRadioButtonPanel.add(extraLargeButton);
    }

    private void createCrustRadioButtonPanel() {
        crustRadioButtonPanel = new JPanel();
        crustRadioButtonPanel.setLayout(new GridLayout(3, 1));
        crustRadioButtonPanel.setBorder(new TitledBorder(new EtchedBorder(), "Crust Type"));
        crustGroup = new ButtonGroup();
        
        thinButton = new JRadioButton("Thin");
        crustGroup.add(thinButton);
        thinButton.addActionListener(listener);
        crustRadioButtonPanel.add(thinButton);
        
        handTossedButton = new JRadioButton("Hand-Tossed");
        crustGroup.add(handTossedButton);
        handTossedButton.addActionListener(listener);
        crustRadioButtonPanel.add(handTossedButton);
        
        deepDishButton = new JRadioButton("Deep-Dish");
        crustGroup.add(deepDishButton);
        deepDishButton.addActionListener(listener);
        crustRadioButtonPanel.add(deepDishButton);
        
        stuffCrustButton = new JRadioButton("Stuff-Crust");
        crustGroup.add(stuffCrustButton);
        stuffCrustButton.addActionListener(listener);
        crustRadioButtonPanel.add(stuffCrustButton);
        
        gutBusterButton = new JRadioButton("Gut-Buster");
        crustGroup.add(gutBusterButton);
        gutBusterButton.addActionListener(listener);
        crustRadioButtonPanel.add(gutBusterButton);
        
        
    }

    private void createToppngCheckBoxPanel() 
    {
        toppingCheckBoxPanel = new JPanel();
        toppingCheckBoxPanel.setLayout(new GridLayout(2, 1));
        
        pepperoniCheckBox = new JCheckBox("Pepperoni");
        pepperoniCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(pepperoniCheckBox);
        
        mushroomsCheckBox = new JCheckBox("Mushrooms");
        mushroomsCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(mushroomsCheckBox);
        
        sausageCheckBox = new JCheckBox("Sausage");
        sausageCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(sausageCheckBox);
        
        baconCheckBox = new JCheckBox("Bacon");
        baconCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(baconCheckBox);
        
        hamCheckBox = new JCheckBox("Ham");
        hamCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(hamCheckBox);
        
        chickenCheckBox = new JCheckBox("Chicken");
        chickenCheckBox.addActionListener(listener);
        toppingCheckBoxPanel.add(chickenCheckBox);
        
    }
    
    private void createButtonAndLabel()
    {
        resultsPanel = new JPanel();
        //resultsPanel.setLayout(new GridLayout(2, 1));
        
        calcPriceButton = new JButton();
        //calcPriceButton.set
        calcPriceButton.setBounds(0, 0, 10, 10);
        calcPriceButton.setText("Calculate Pizza Price");
        calcPriceButton.addActionListener(listener2);
        
        label = new JLabel("");
        label.setBounds(0, 0, 50, 40);
        resultsPanel.add(calcPriceButton);
        resultsPanel.add(label);

    }
    
    private void createCenterPanel() 
    {
        centerPanel = new JPanel();
        centerPanel.add(sizeRadioButtonPanel);
        centerPanel.add(crustRadioButtonPanel);
        centerPanel.add(toppingCheckBoxPanel);
    }

   private class PriceListener implements ActionListener 
   {
        public void actionPerformed(ActionEvent event) 
        {
            topPrice = 0;
            if (smallButton.isSelected()) 
            {
                price = 7.00;
            } else if (mediumButton.isSelected()) 
            {
                price = 9.00;
            } else if (largeButton.isSelected()) 
            {
                price = 11.00;
            }
            else if (extraLargeButton.isSelected())
            {
                price = 13.00;
            }
            
            JCheckBox cBoxes[] = {pepperoniCheckBox, mushroomsCheckBox,
                sausageCheckBox, baconCheckBox, hamCheckBox, chickenCheckBox};
            
            //Toppings are 50 cents. Loop to check which are selected.
            for(int i = 0; i < cBoxes.length; i++)
                if(cBoxes[i].isSelected())
                    topPrice += .50;
            System.out.println("Size Price: " + Double.toString(price));
            System.out.println("Topping Price: " + Double.toString(topPrice));
        }
    }
   
    private class DisplayPriceListener implements ActionListener 
    {
        public void actionPerformed(ActionEvent event) 
        {
            System.out.println("Size Price: " + Double.toString(price));
            System.out.println("Topping Price: " + Double.toString(topPrice));
            label.setText("Size Price: "  + Double.toString(price));
            
        }
    }
    public static void main(String[] args) 
    {
        PizzeriaFrame PizzaOrder = new PizzeriaFrame();
    }
}