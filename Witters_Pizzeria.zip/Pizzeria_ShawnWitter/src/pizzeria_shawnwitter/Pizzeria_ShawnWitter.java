/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria_shawnwitter;

import java.sql.*;

public class Pizzeria_ShawnWitter 
{
    public static void main(String[] args) 
    {
        final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDb";

        try
        {
            Connection con = DriverManager.getConnection(DB_URL);
            System.out.println("Connection to [DB Name] created.");
            
            Statement stmt = con.createStatement();
            
            //Create a PizzaSize Table
            PizzaSizeTable pst = new PizzaSizeTable();
            
            //Insert Default Size Data
            pst.insertRow("'Small'", 7.00);
            pst.insertRow("'Medium'", 9.00);
            pst.insertRow("'Large'", 11.00);
            pst.insertRow("'Extra-Large'", 13.00);
            
            //Display Data
            pst.displayResultSet();
            //Update Row Example and Display Data
            pst.updateRow("'Extra Small'", 5.00, "'Small'");
            pst.displayResultSet();
            //Delete Row Example and Display Data                        
            pst.deleteRow("'Extra Small'");
            pst.displayResultSet();
            
            //Create a PizzaCrust Table
            PizzaCrustTable pct = new PizzaCrustTable();
            
            //Insert Default Crust Data
            pct.insertRow("'Thin'");
            pct.insertRow("'Hand-Tossed'");
            pct.insertRow("'Deep-Dish'");
            pct.insertRow("'Stuffed-Crust'");
            pct.insertRow("'Gut-Buster'");
            
            //Display Data
            pct.displayResultSet();
            //Update Row Example and Display Data
            pct.updateRow("'Super Thin'", "'Thin'");
            pct.displayResultSet();
            //Delete Row Example and Display Data                        
            pct.deleteRow("'Super Thin'");
            pct.displayResultSet();

            PizzaToppingsTable ptt = new PizzaToppingsTable();
            
            ptt.insertRow("'Pepperoni'", .50);
            ptt.insertRow("'Sausage'", .50);
            ptt.insertRow("'Ham'", .50);
            ptt.insertRow("'Bacon'", .50);
            ptt.insertRow("'Chicken'", .50);
            ptt.insertRow("'Hamburger'", .50);
            ptt.insertRow("'Extra Cheese'", .50);
            ptt.insertRow("'Onions'", .50);
            ptt.insertRow("'Green Peppers'", .50);
            ptt.insertRow("'Mushrooms'", .50);
            ptt.insertRow("'Black Olives'", .50);
            ptt.insertRow("'Sliced Tomatoes'", .50);
            ptt.insertRow("'Feta Cheese'", .50);

            //Display Data
            ptt.displayResultSet();
            //Update Row Example and Display Data
            ptt.updateRow("'Pineapple'", .50, "'Pepperoni'");
            ptt.displayResultSet();
            //Delete Row Example and Display Data                        
            ptt.deleteRow("'Pineapple'");
            ptt.displayResultSet();
            
            
            //String sqlStmt3 = "CREATE TABLE PizzaToppings (ToppingName CHAR(30), Price DOUBLE)";
            
            //Close the Connection
            con.close();
            System.out.println("Connection Closed.");
        }
        catch(Exception ex)
        {
            System.out.println("ERROR: " + ex.getMessage());
        }
    }
    
}
