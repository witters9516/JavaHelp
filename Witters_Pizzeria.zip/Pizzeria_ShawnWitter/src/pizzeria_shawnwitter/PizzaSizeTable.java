/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria_shawnwitter;

import java.sql.*;

public class PizzaSizeTable 
{
    final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDb";
    
    

    public PizzaSizeTable()
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           
           String sqlDrop1 = "DROP TABLE PizzaSizes";
           stmt.execute(sqlDrop1);
            
            
           String sqlStmt1 = "CREATE TABLE PizzaSizes(SizeName CHAR(15), Price DOUBLE)";
           stmt.execute(sqlStmt1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertRow(String sizeName, double price)
    {
        
        try
        {
            Connection con = DriverManager.getConnection(DB_URL);
            Statement stmt = con.createStatement();

            //Create add statements to insert data.
            String sqlAdd = "INSERT INTO PizzaSizes(SizeName, Price) VALUES(" + sizeName + ", " + price + ")";
            stmt.executeUpdate(sqlAdd);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        } 
    }
    
    public void displayResultSet()
    {
       //ResultSet result1 = new ResultSet();
       try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "SELECT * FROM PizzaSizes";
            ResultSet result1 = stmt.executeQuery(sqlDisplay1);
            
            //Display Database
            System.out.println("PizzaSizes Table:");
            System.out.println("Size Name:\tPrice");
            
            while (result1.next())
                System.out.println(result1.getString(1) + "\t" + result1.getString(2));
            
            //return result1;

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void updateRow(String new_SizeName, double price, String original_SizeName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "UPDATE PizzaSizes SET SizeName=" + new_SizeName + ", Price= " + price +
                    "WHERE SizeName=" + original_SizeName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void deleteRow(String original_SizeName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "DELETE FROM PizzaSizes WHERE SizeName=" + original_SizeName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}
