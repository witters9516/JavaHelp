/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retailpricecalculator_shawnwitter.java;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
/**
 *
 * @author witters9516
 */
public class RetailPriceCalculator_ShawnWitter 
{
    public void initialize()
    {
        //Nothing to initialize
    }
    
    @FXML
    private Label outputLabel;

    @FXML
    private TextField wholesaleTextField;

    @FXML
    private Button calculateButton;

    @FXML
    private TextField markupTextField;
    
    public void calculateButtonListener()
    {
        //Get the wholesale cost
        double wholesale = Double.parseDouble(wholesaleTextField.getText());
        
        //Get the markup percentage
        double markup = Double.parseDouble(markupTextField.getText());
        
        //Calculate the retail price
        double retail = wholesale + (wholesale * markup);
        
        //Display the retail price
        outputLabel.setText("The retail price is $" + retail);
    }
    
}
