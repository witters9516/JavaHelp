/**
* This program calculates the markup percentage using Java FX Scene Builder.
* 11/22/17
* CSC 251 Lab 11 - Retail Price Calculator
* Shawn Witter
*/
package retailpricecalculator_shawnwitter.java;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class RetailPriceCalculator_ShawnWitterJava extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        //Load the FXML file.
        Parent parent = FXMLLoader.load(getClass().getResource("RetailPriceCalculator__ShawnWitter.fxml"));
        
        //Buuild the scene graph.
        Scene scene = new Scene(parent);
        
        //Display our window, using the scene graph.
        primaryStage.setTitle("Retail Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
