/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria;

/**
 *
 * 12/11/2017
 * CSC 251 Project 2 -Pizzeria
 * @author Michael Cook
 */

import javax.swing.JFrame;

public class Pizzeria 
{
    public static void main(String[] args) 
    {
        JFrame frame = new PizzeriaFrame();
	frame.setTitle("Pizza Price");
    }
    
}
