/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzeria_shawnwitter;

import java.sql.*;

public class PizzaCrustTable 
{
    final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDb";
    
    public PizzaCrustTable()
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           
           String sqlDrop1 = "DROP TABLE PizzaCrusts";
           stmt.execute(sqlDrop1);
            
            
           String sqlStmt1 = "CREATE TABLE PizzaCrusts(TypeName CHAR(30))";
           stmt.execute(sqlStmt1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertRow(String typeName)
    {
        
        try
        {
            Connection con = DriverManager.getConnection(DB_URL);
            Statement stmt = con.createStatement();

            //Create add statements to insert data.
            String sqlAdd = "INSERT INTO PizzaCrusts(TypeName) VALUES(" + typeName + ")";
            stmt.executeUpdate(sqlAdd);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        } 
    }
    
    public void displayResultSet()
    {
       //ResultSet result1 = new ResultSet();
       try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "SELECT * FROM PizzaCrusts";
            ResultSet result1 = stmt.executeQuery(sqlDisplay1);
            
            //Display Database
            System.out.println("PizzaCrusts Table:");
            System.out.println("TypeName");
            
            while (result1.next())
                System.out.println(result1.getString(1));
            
            //return result1;

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void updateRow(String new_TypeName, String original_TypeName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "UPDATE PizzaCrusts SET TypeName=" + new_TypeName +
                    "WHERE TypeName=" + original_TypeName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
    public void deleteRow(String original_TypeName)
    {
        try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();

           //Create ResultSet for display
            String sqlDisplay1 = "DELETE FROM PizzaCrusts WHERE TypeName=" + original_TypeName;
            int result1 = stmt.executeUpdate(sqlDisplay1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
    
}
